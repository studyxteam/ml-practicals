//Write a program to solve a fractional Knapsack problem using a greedy method.
// ------------------------------------------------------------------------------------------------------------------------
#include <bits/stdc++.h>
using namespace std;
struct Item {
int profit, weight;
// Constructor
Item(int profit, int weight)
{
this->profit = profit;
this->weight = weight;
}
};
static bool cmp(struct Item a, struct Item b)
{
double r1 = (double)a.profit / (double)a.weight;
double r2 = (double)b.profit / (double)b.weight;
return r1 > r2;
}
//r1 = (double)a.profit / (double)a.weight;

// This calculates the profit-to-weight ratio for item a.
// It tells how much profit can be gained per unit weight of item a.
// r2 = (double)b.profit / (double)b.weight;

// This calculates the profit-to-weight ratio for item b.
// It tells how much profit can be gained per unit weight of item b.

double fractionalKnapsack(int W, struct Item arr[], int N)
{
sort(arr, arr + N, cmp);
double finalvalue = 0.0;
for (int i = 0; i < N; i++) {
if (arr[i].weight <= W) {
W =W- arr[i].weight;
finalvalue =finalvalue + arr[i].profit;
}
else {
finalvalue += arr[i].profit * ((double)W / (double)arr[i].weight);
break;
}
}
return finalvalue;
}
int main()
{
int W = 50;
Item arr[] = { { 60, 10 }, { 100, 20 }, { 120, 30 } };
int N = sizeof(arr) / sizeof(arr[0]);
cout << fractionalKnapsack(W, arr, N);
return 0;
}

// You have a knapsack (a bag) that can hold a maximum weight 
// 𝑊
// W. You have several items, each with a specific weight and profit. The goal is to maximize the profit you can carry in the knapsack. Unlike the 0/1 knapsack problem, in the fractional knapsack, you can take fractions of items.

// Example
// Let’s consider the following example:

// Maximum weight capacity of knapsack (W): 50 units
// Items available:
// Item 1: Profit = 60, Weight = 10
// Item 2: Profit = 100, Weight = 20
// Item 3: Profit = 120, Weight = 30
// Steps to Solve the Problem
// Calculate Profit-to-Weight Ratio: For each item, calculate the profit-to-weight ratio:

// Item 1: 
// 60
// 10
// =
// 6
// 10
// 60
// ​
//  =6
// Item 2: 
// 100
// 20
// =
// 5
// 20
// 100
// ​
//  =5
// Item 3: 
// 120
// 30
// =
// 4
// 30
// 120
// ​
//  =4
// This means:

// Item 1 gives you 6 profit units per weight unit.
// Item 2 gives you 5 profit units per weight unit.
// Item 3 gives you 4 profit units per weight unit.
// Sort Items by Ratio: Sort the items in descending order based on their profit-to-weight ratio:

// Item 1 (ratio 6)
// Item 2 (ratio 5)
// Item 3 (ratio 4)
// Select Items for the Knapsack: Start filling the knapsack from the highest ratio item to the lowest:

// First item (Item 1):
// Weight = 10, Profit = 60
// Remaining capacity = 50 - 10 = 40
// Total profit = 0 + 60 = 60
// Second item (Item 2):
// Weight = 20, Profit = 100
// Remaining capacity = 40 - 20 = 20
// Total profit = 60 + 100 = 160
// Third item (Item 3):
// Weight = 30 (but we can only take a fraction)
// We can only take 20 units of this item because our knapsack can only hold 20 more.
// Profit from the fraction = 
// 120
// ×
// 20
// 30
// =
// 80
// 120× 
// 30
// 20
// ​
//  =80
// Total profit = 160 + 80 = 240
// Final Calculation
// After considering all items, the maximum profit we can achieve is 240 units.

// Summary of Logic and Flow
// Identify items with their profits and weights.
// Calculate the profit-to-weight ratio for each item.
// Sort the items based on the ratio (highest to lowest).
// Greedily add items to the knapsack:
// If the entire item fits, add it completely.
// If it doesn’t fit, add as much as possible (a fraction) and stop.


// The fractionalKnapsack function calculates the maximum profit that can be obtained by filling a knapsack with a given weight capacity 
// 𝑊
// W using a list of items. Each item has a profit and weight associated with it. This function uses a greedy approach to solve the problem.

// Code Breakdown
// cpp
// Copy code
// double fractionalKnapsack(int W, struct Item arr[], int N) {
// Function Declaration: The function takes three parameters:
// W: Maximum weight capacity of the knapsack.
// arr[]: Array of Item structures (each with profit and weight).
// N: Number of items.
// Step 1: Sort the Items
// cpp
// Copy code
// sort(arr, arr + N, cmp);
// Sorting: The first operation is to sort the items based on their profit-to-weight ratio using the cmp function (which was defined earlier). This ensures that we will always try to take the most profitable items first.
// Logic: By sorting, we prioritize items that give us the highest profit for each unit of weight. This is a key step in maximizing our total profit.

// Step 2: Initialize Final Profit
// cpp
// Copy code
// double finalvalue = 0.0;
// Initialization: We create a variable finalvalue to keep track of the total profit we can achieve as we fill the knapsack.
// Step 3: Iterate Through the Sorted Items
// cpp
// Copy code
// for (int i = 0; i < N; i++) {
// Loop: We start a loop that goes through each item in the sorted array.
// Step 4: Check If Item Fits Completely
// cpp
// Copy code
// if (arr[i].weight <= W) {
//     W -= arr[i].weight;
//     finalvalue += arr[i].profit;
// }
// Condition: For each item, we check if its weight is less than or equal to the remaining capacity of the knapsack (W).
// If yes:
// We can take the whole item.
// We reduce the remaining capacity W by the item's weight.
// We add the item's profit to finalvalue.
// Logic: This part of the loop ensures that we maximize our profit by adding entire items as long as they fit in the knapsack.

// Step 5: Handle Remaining Capacity (Partial Item)
// cpp
// Copy code
// else {
//     finalvalue += arr[i].profit * ((double)W / (double)arr[i].weight);
//     break;
// }
// Else Condition: If the current item does not fit completely:
// We calculate how much of the item we can take based on the remaining capacity (W).
// We calculate the profit from the fraction of the item that can be added:
// Profit from fraction
// =
// Profit
// ×
// (
// Remaining Capacity
// Weight of Item
// )
// Profit from fraction=Profit×( 
// Weight of Item
// Remaining Capacity
// ​
//  )
// We add this calculated profit to finalvalue.
// We then break out of the loop because the knapsack is now full (we can't add any more items).
// Logic: This handles the case where we cannot take a whole item, allowing us to still gain profit by taking as much of it as possible.

// Step 6: Return Total Profit
// cpp
// Copy code
// return finalvalue;
// }
// Return Statement: Finally, the function returns the total profit (finalvalue) that we can achieve with the items selected.
// Summary of Flow
// Sort items based on profit-to-weight ratio to prioritize more profitable items.
// Initialize total profit to zero.
// Loop through sorted items:
// If an item fits in the remaining capacity, add its full profit and reduce capacity.
// If it doesn't fit, add the fraction of its profit that corresponds to the remaining capacity, then exit the loop.
// Return the total profit achieved.
// Example Walkthrough
// Let’s consider a simple example:

// Capacity (W): 50
// Items:
// Item 1: Profit = 60, Weight = 10
// Item 2: Profit = 100, Weight = 20
// Item 3: Profit = 120, Weight = 30
// After Sorting:

// Item 1 (ratio 6)
// Item 2 (ratio 5)
// Item 3 (ratio 4)
// Iteration:

// Item 1:
// Weight = 10 → Fits! (Remaining W = 40) → Total Profit = 60.
// Item 2:
// Weight = 20 → Fits! (Remaining W = 20) → Total Profit = 160.
// Item 3:
// Weight = 30 → Doesn’t fit (Remaining W = 20) → Take fraction:
// Profit from Item 3
// =
// 120
// ×
// (
// 20
// 30
// )
// =
// 80.
// Profit from Item 3=120×( 
// 30
// 20
// ​
//  )=80.
// Total Profit = 240.
// This structured flow makes the algorithm efficient and clear, resulting in the maximum profit for the given capacity.






