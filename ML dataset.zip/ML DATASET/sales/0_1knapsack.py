def knapsack(W, wt, val, n):
    # Initialize dp array to store maximum values for weights up to W
    dp = [0 for _ in range(W + 1)]

    # Loop through each item
    for i in range(1, n + 1):
        # Traverse dp array in reverse order to avoid using an item more than once
        for w in range(W, 0, -1):
            if wt[i - 1] <= w:  # Check if the item's weight is within the current weight limit
                dp[w] = max(dp[w], dp[w - wt[i - 1]] + val[i - 1])  # Choose max value

    return dp[W]  # Max value achievable with weight limit W

# Sample input
val = [20,50,150]
wt = [20,50,90]
W = 110
n = len(val)
print(knapsack(W, wt, val, n))  # Output should be 220
