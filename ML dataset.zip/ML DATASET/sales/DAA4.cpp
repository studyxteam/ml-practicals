//Write a program to solve a 0-1 Knapsack problem using dynamic programming or branch and bound
// strategy. 
#include <bits/stdc++.h>
using namespace std;

// Function to solve the 0/1 Knapsack problem using Dynamic Programming
int knapSack(int W, int wt[], int val[], int n) {
    // Step 1: Create a 2D DP table to store maximum profit values
    vector<vector<int>> dp(n + 1, vector<int>(W + 1, 0));

    // Step 2: Fill the DP table in a bottom-up manner
    for (int i = 1; i <= n; i++) { // Iterate over each item
        for (int w = 1; w <= W; w++) { // Iterate over each capacity from 1 to W
            if (wt[i - 1] <= w) { // Check if current item can fit into current capacity
                dp[i][w] = max(val[i - 1] + dp[i - 1][w - wt[i - 1]], dp[i - 1][w]);
            } else { // Item can't fit; take value without including this item
                dp[i][w] = dp[i - 1][w];
            }
        }
    }

    // Step 3: Return the maximum profit achievable with n items and capacity W
    return dp[n][W];
}

int main() {
    int profit[] = {20, 50, 150}; // Array of profits for each item
    int weight[] = {20, 50, 90};  // Array of weights for each item
    int W = 110; // Maximum weight capacity of the knapsack
    int n = sizeof(profit) / sizeof(profit[0]); // Total number of items

    // Call knapSack function and output the result
    cout << "Maximum profit: " << knapSack(W, weight, profit, n) << endl;
    return 0;
}
